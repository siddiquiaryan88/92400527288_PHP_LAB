<?php
require_once 'config.php';

$errors = [];
$name = '';
$email = '';
$phone = '';
$role = '';
$status = 'Active';
$salary = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name   = trim($_POST['name'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $phone  = trim($_POST['phone'] ?? '');
    $role   = trim($_POST['role'] ?? '');
    $status = trim($_POST['status'] ?? 'Active');
    $salary = trim($_POST['salary'] ?? '');

    // Validation Rules
    if (empty($name)) {
        $errors[] = "Full Name is required.";
    }

    if (empty($email)) {
        $errors[] = "Email Address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format provided.";
    } else {
        // Check for duplicate email in DB
        $checkStmt = $pdo->prepare("SELECT id FROM employees WHERE email = :email");
        $checkStmt->execute(['email' => $email]);
        if ($checkStmt->rowCount() > 0) {
            $errors[] = "An employee with this email already exists.";
        }
    }

    if (empty($phone)) {
        $errors[] = "Phone Number is required.";
    }

    if (empty($role)) {
        $errors[] = "Job Role is required.";
    }

    if (!in_array($status, ['Active', 'Inactive', 'On Leave'])) {
        $errors[] = "Invalid status value selected.";
    }

    if (empty($salary)) {
        $errors[] = "Salary is required.";
    } elseif (!is_numeric($salary) || $salary < 0) {
        $errors[] = "Salary must be a valid positive number.";
    }

    // Save if no errors
    if (empty($errors)) {
        try {
            $insertSql = "INSERT INTO employees (name, email, phone, role, status, salary) 
                          VALUES (:name, :email, :phone, :role, :status, :salary)";
            $stmt = $pdo->prepare($insertSql);
            $stmt->execute([
                'name'   => $name,
                'email'  => $email,
                'phone'  => $phone,
                'role'   => $role,
                'status' => $status,
                'salary' => $salary
            ]);

            set_flash('success', "Employee '{$name}' created successfully!");
            header("Location: index.php");
            exit;
        } catch (PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Employee | PHP CRUD</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="app-header">
        <div class="container header-content">
            <div class="brand">
                <div class="brand-icon">⚡</div>
                <div class="brand-title">
                    <h1>Employee Hub</h1>
                    <p>Add New Record</p>
                </div>
            </div>
            <a href="index.php" class="btn btn-secondary">
                ← Back to Dashboard
            </a>
        </div>
    </header>

    <main class="container">
        <div class="form-card">
            <div class="form-header">
                <div class="form-title">
                    <h2>Add New Employee</h2>
                    <p>Enter the details below to create a new employee profile.</p>
                </div>
            </div>

            <!-- Validation Error Messages -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <span class="alert-icon">⚠️</span>
                    <div>
                        <strong>Please resolve the following errors:</strong>
                        <ul style="margin-top: 0.4rem; padding-left: 1.25rem;">
                            <?php foreach ($errors as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <form method="POST" action="create.php">
                <div class="form-grid">
                    
                    <div class="form-group">
                        <label for="name">Full Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="e.g. Jane Doe" value="<?= htmlspecialchars($name) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address <span class="required">*</span></label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="jane.doe@example.com" value="<?= htmlspecialchars($email) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number <span class="required">*</span></label>
                        <input type="text" id="phone" name="phone" class="form-control" placeholder="+1 (555) 000-0000" value="<?= htmlspecialchars($phone) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="role">Job Role / Title <span class="required">*</span></label>
                        <input type="text" id="role" name="role" class="form-control" placeholder="e.g. Software Engineer" value="<?= htmlspecialchars($role) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="status">Employment Status <span class="required">*</span></label>
                        <select id="status" name="status" class="form-control" required>
                            <option value="Active" <?= $status === 'Active' ? 'selected' : '' ?>>Active</option>
                            <option value="Inactive" <?= $status === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                            <option value="On Leave" <?= $status === 'On Leave' ? 'selected' : '' ?>>On Leave</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="salary">Annual Salary ($) <span class="required">*</span></label>
                        <input type="number" step="0.01" min="0" id="salary" name="salary" class="form-control" placeholder="75000.00" value="<?= htmlspecialchars($salary) ?>" required>
                    </div>

                </div>

                <div class="form-actions">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Employee</button>
                </div>
            </form>
        </div>
    </main>

</body>
</html>
