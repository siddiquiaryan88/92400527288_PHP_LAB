<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'crud_db');

try {
    // 1. Connect without selecting database to check/create database
    $pdoInit = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    
    // Auto-create database if it doesn't exist
    $pdoInit->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    
    // 2. Connect to the specific database
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    
    // Auto-create table if it doesn't exist
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'employees'");
    if ($tableCheck->rowCount() === 0) {
        $createTableSql = "CREATE TABLE `employees` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `name` VARCHAR(100) NOT NULL,
          `email` VARCHAR(100) NOT NULL UNIQUE,
          `phone` VARCHAR(20) NOT NULL,
          `role` VARCHAR(50) NOT NULL,
          `status` ENUM('Active', 'Inactive', 'On Leave') DEFAULT 'Active',
          `salary` DECIMAL(10, 2) NOT NULL,
          `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        
        $pdo->exec($createTableSql);
        
        // Insert sample seed data
        $seedSql = "INSERT INTO `employees` (`name`, `email`, `phone`, `role`, `status`, `salary`) VALUES
            ('Sarah Connor', 'sarah.c@example.com', '+1 (555) 234-5678', 'Software Engineer', 'Active', 85000.00),
            ('Alex Morgan', 'alex.m@example.com', '+1 (555) 876-5432', 'UI/UX Designer', 'Active', 72000.00),
            ('David Miller', 'david.m@example.com', '+1 (555) 345-6789', 'Project Manager', 'On Leave', 95000.00),
            ('Emily Chen', 'emily.c@example.com', '+1 (555) 987-6543', 'QA Specialist', 'Inactive', 64000.00)";
        $pdo->exec($seedSql);
    }
    
} catch (PDOException $e) {
    // If DB connection fails, display a user-friendly error card instead of a raw crash
    die("
    <div style='font-family: system-ui, -apple-system, sans-serif; padding: 2rem; max-width: 600px; margin: 4rem auto; background: #fff5f5; border: 1px solid #feb2b2; border-radius: 12px; color: #9b2c2c;'>
        <h2 style='margin-top: 0;'>⚠️ Database Connection Failed</h2>
        <p>Could not connect to MySQL server. Please ensure MySQL is running (e.g., via XAMPP, WAMP, or Laragon).</p>
        <p style='background: #fff; padding: 0.75rem; border-radius: 6px; font-family: monospace; font-size: 0.875rem;'><strong>Details:</strong> " . htmlspecialchars($e->getMessage()) . "</p>
        <p><strong>Default Credentials:</strong> Host: <code>localhost</code> | User: <code>root</code> | Pass: <code>(empty)</code></p>
    </div>
    ");
}

// Session management for flash messages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Helper to set flash notifications
 */
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success' or 'error'
        'message' => $message
    ];
}

/**
 * Helper to display and clear flash notifications
 */
function display_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        $icon = ($flash['type'] === 'success') ? '✓' : '⚠️';
        $class = ($flash['type'] === 'success') ? 'alert-success' : 'alert-error';
        echo "<div class='alert {$class}'>
                <span class='alert-icon'>{$icon}</span>
                <span>" . htmlspecialchars($flash['message']) . "</span>
              </div>";
    }
}
