<?php
require_once 'config.php';

// Get search and filter inputs
$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

// 1. Fetch Analytics & Stats
$totalStmt = $pdo->query("SELECT COUNT(*) FROM employees");
$totalEmployees = $totalStmt->fetchColumn();

$activeStmt = $pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'");
$activeEmployees = $activeStmt->fetchColumn();

$leaveStmt = $pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'On Leave'");
$leaveEmployees = $leaveStmt->fetchColumn();

$payrollStmt = $pdo->query("SELECT SUM(salary) FROM employees");
$totalPayroll = $payrollStmt->fetchColumn() ?: 0;

// 2. Build Filtered Query for Employee List
$sql = "SELECT * FROM employees WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (name LIKE :search OR email LIKE :search OR role LIKE :search)";
    $params['search'] = "%{$search}%";
}

if ($statusFilter !== '') {
    $sql .= " AND status = :status";
    $params['status'] = $statusFilter;
}

$sql .= " ORDER BY id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management System | PHP CRUD</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="app-header">
        <div class="container header-content">
            <div class="brand">
                <div class="brand-icon">⚡</div>
                <div class="brand-title">
                    <h1>Employee Hub</h1>
                    <p>PHP MySQL Management System</p>
                </div>
            </div>
            <a href="create.php" class="btn btn-primary">
                <span>+</span> Add New Employee
            </a>
        </div>
    </header>

    <main class="container">
        <!-- Flash Alert Messages -->
        <?php display_flash(); ?>

        <!-- Analytical Statistics -->
        <section class="stats-grid">
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Total Staff</div>
                    <div class="stat-value"><?= number_format($totalEmployees) ?></div>
                </div>
                <div class="stat-badge stat-purple">👥</div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Active Staff</div>
                    <div class="stat-value"><?= number_format($activeEmployees) ?></div>
                </div>
                <div class="stat-badge stat-green">✅</div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">On Leave</div>
                    <div class="stat-value"><?= number_format($leaveEmployees) ?></div>
                </div>
                <div class="stat-badge stat-amber">🌴</div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <div class="stat-label">Monthly Payroll</div>
                    <div class="stat-value">$<?= number_format($totalPayroll, 2) ?></div>
                </div>
                <div class="stat-badge stat-blue">💳</div>
            </div>
        </section>

        <!-- Search and Filter Toolbar -->
        <section class="toolbar">
            <form method="GET" action="index.php" class="search-filter-group">
                <div class="search-box">
                    <span class="search-icon">🔍</span>
                    <input type="text" name="search" placeholder="Search by name, email, or role..." value="<?= htmlspecialchars($search) ?>">
                </div>

                <select name="status" class="select-filter" onchange="this.form.submit()">
                    <option value="">All Statuses</option>
                    <option value="Active" <?= $statusFilter === 'Active' ? 'selected' : '' ?>>Active</option>
                    <option value="Inactive" <?= $statusFilter === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                    <option value="On Leave" <?= $statusFilter === 'On Leave' ? 'selected' : '' ?>>On Leave</option>
                </select>

                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                
                <?php if ($search !== '' || $statusFilter !== ''): ?>
                    <a href="index.php" class="btn btn-secondary btn-sm">Reset</a>
                <?php endif; ?>
            </form>
        </section>

        <!-- Data Table Container -->
        <section class="card-table">
            <div class="table-responsive">
                <?php if (count($employees) > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Salary</th>
                                <th>Status</th>
                                <th>Joined Date</th>
                                <th style="text-align: right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($employees as $emp): ?>
                                <?php
                                    // Generate initials for avatar
                                    $words = explode(' ', $emp['name']);
                                    $initials = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));
                                    
                                    // Status badge class mapping
                                    $statusClass = 'badge-active';
                                    if ($emp['status'] === 'Inactive') $statusClass = 'badge-inactive';
                                    if ($emp['status'] === 'On Leave') $statusClass = 'badge-on-leave';
                                ?>
                                <tr>
                                    <td>
                                        <div class="user-cell">
                                            <div class="avatar-badge"><?= $initials ?></div>
                                            <div>
                                                <div class="user-name"><?= htmlspecialchars($emp['name']) ?></div>
                                                <div class="user-email"><?= htmlspecialchars($emp['email']) ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($emp['phone']) ?></td>
                                    <td><strong><?= htmlspecialchars($emp['role']) ?></strong></td>
                                    <td>$<?= number_format($emp['salary'], 2) ?></td>
                                    <td>
                                        <span class="badge <?= $statusClass ?>">
                                            <?= htmlspecialchars($emp['status']) ?>
                                        </span>
                                    </td>
                                    <td><?= date('M d, Y', strtotime($emp['created_at'])) ?></td>
                                    <td>
                                        <div class="action-buttons" style="justify-content: flex-end;">
                                            <a href="read.php?id=<?= $emp['id'] ?>" class="btn-icon view" title="View Profile">👁️</a>
                                            <a href="edit.php?id=<?= $emp['id'] ?>" class="btn-icon edit" title="Edit Record">✏️</a>
                                            <a href="delete.php?id=<?= $emp['id'] ?>" 
                                               class="btn-icon delete" 
                                               title="Delete Record"
                                               onclick="return confirm('Are you sure you want to delete employee: <?= htmlspecialchars($emp['name']) ?>?');">
                                               🗑️
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">📁</div>
                        <div class="empty-title">No Employees Found</div>
                        <div class="empty-desc">No records match your search criteria. Try clearing filters or create a new employee.</div>
                        <a href="create.php" class="btn btn-primary">+ Add New Employee</a>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

</body>
</html>
