<?php
require_once 'config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    set_flash('error', "Invalid employee ID specified.");
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = :id");
$stmt->execute(['id' => $id]);
$employee = $stmt->fetch();

if (!$employee) {
    set_flash('error', "Employee record not found.");
    header("Location: index.php");
    exit;
}

// Generate initials for profile banner
$words = explode(' ', $employee['name']);
$initials = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));

// Status badge styling
$statusClass = 'badge-active';
if ($employee['status'] === 'Inactive') $statusClass = 'badge-inactive';
if ($employee['status'] === 'On Leave') $statusClass = 'badge-on-leave';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($employee['name']) ?> - Profile | PHP CRUD</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="app-header">
        <div class="container header-content">
            <div class="brand">
                <div class="brand-icon">⚡</div>
                <div class="brand-title">
                    <h1>Employee Hub</h1>
                    <p>Profile View</p>
                </div>
            </div>
            <a href="index.php" class="btn btn-secondary">
                ← Back to Dashboard
            </a>
        </div>
    </header>

    <main class="container">
        <div class="profile-card">
            <div class="profile-banner">
                <div class="profile-avatar-wrapper">
                    <?= $initials ?>
                </div>
            </div>

            <div class="profile-body">
                <div class="profile-name-row">
                    <div>
                        <h2><?= htmlspecialchars($employee['name']) ?></h2>
                        <p><?= htmlspecialchars($employee['role']) ?></p>
                    </div>
                    <span class="badge <?= $statusClass ?>">
                        <?= htmlspecialchars($employee['status']) ?>
                    </span>
                </div>

                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Employee ID</div>
                        <div class="detail-value">#EMP-<?= str_pad($employee['id'], 4, '0', STR_PAD_LEFT) ?></div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">Email Address</div>
                        <div class="detail-value"><?= htmlspecialchars($employee['email']) ?></div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">Phone Number</div>
                        <div class="detail-value"><?= htmlspecialchars($employee['phone']) ?></div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">Annual Salary</div>
                        <div class="detail-value">$<?= number_format($employee['salary'], 2) ?></div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">Status</div>
                        <div class="detail-value"><?= htmlspecialchars($employee['status']) ?></div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">Date Joined</div>
                        <div class="detail-value"><?= date('F d, Y - h:i A', strtotime($employee['created_at'])) ?></div>
                    </div>
                </div>

                <div style="display: flex; gap: 0.75rem; justify-content: flex-end;">
                    <a href="edit.php?id=<?= $employee['id'] ?>" class="btn btn-primary">
                        ✏️ Edit Employee
                    </a>
                    <a href="delete.php?id=<?= $employee['id'] ?>" 
                       class="btn btn-danger"
                       onclick="return confirm('Are you sure you want to delete this employee?');">
                        🗑️ Delete
                    </a>
                </div>
            </div>
        </div>
    </main>

</body>
</html>
