-- Database schema for PHP MySQL CRUD Application
CREATE DATABASE IF NOT EXISTS `crud_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `crud_db`;

CREATE TABLE IF NOT EXISTS `employees` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(20) NOT NULL,
  `role` VARCHAR(50) NOT NULL,
  `status` ENUM('Active', 'Inactive', 'On Leave') DEFAULT 'Active',
  `salary` DECIMAL(10, 2) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample Seed Data
INSERT INTO `employees` (`name`, `email`, `phone`, `role`, `status`, `salary`) VALUES
('Sarah Connor', 'sarah.c@example.com', '+1 (555) 234-5678', 'Software Engineer', 'Active', 85000.00),
('Alex Morgan', 'alex.m@example.com', '+1 (555) 876-5432', 'UI/UX Designer', 'Active', 72000.00),
('David Miller', 'david.m@example.com', '+1 (555) 345-6789', 'Project Manager', 'On Leave', 95000.00),
('Emily Chen', 'emily.c@example.com', '+1 (555) 987-6543', 'QA Specialist', 'Inactive', 64000.00);
