<?php
require_once 'config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    set_flash('error', "Invalid employee ID specified for deletion.");
    header("Location: index.php");
    exit;
}

try {
    // Fetch employee name before deletion for flash message
    $fetchStmt = $pdo->prepare("SELECT name FROM employees WHERE id = :id");
    $fetchStmt->execute(['id' => $id]);
    $employee = $fetchStmt->fetch();

    if ($employee) {
        $deleteStmt = $pdo->prepare("DELETE FROM employees WHERE id = :id");
        $deleteStmt->execute(['id' => $id]);
        set_flash('success', "Employee '{$employee['name']}' was successfully deleted.");
    } else {
        set_flash('error', "Employee record not found.");
    }
} catch (PDOException $e) {
    set_flash('error', "Failed to delete record: " . $e->getMessage());
}

header("Location: index.php");
exit;
